export const tasks=[
    {
        id:0,
        contenido: "tarea 1",
        done: false
    },    
    {
        id:1,
        contenido: "tarea 2",
        done: false
    },    
    {
        id:2,
        contenido: "tarea 3",
        done: false
    }

];